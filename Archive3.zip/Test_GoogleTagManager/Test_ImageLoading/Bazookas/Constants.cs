﻿// //
// //Constants.cs$
// //
// // Author:
// //       Bruneel Robin <robin@bazookas.be>
// //
// // Copyright (c) 2015 Robin Bruneel
using System;

namespace Bazookas
{
	public static class Constants
	{
		public	const string googleTagManager_ID = "GTM-N9FFXD";
	}
}

