﻿using System;
using Bazookas.RecyclerViewCells;
using Com.Bumptech.Glide;

namespace Test_ImageLoading
{
	public class RecyclerViewCell_Image_Glide: RecyclerViewCell_Image
	{
		public RecyclerViewCell_Image_Glide(Android.Content.Context context, string imageUrl) : base(context, imageUrl)
		{
		}

		public override void LoadImage()
		{
			Glide.With(Context)
				 .Load(ImageUrl)
				 .Into(ViewHolder.Image);
		}
	}
}

