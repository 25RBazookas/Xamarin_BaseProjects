﻿//
// IBitmapScaled.cs
//
// Author:
//       Philippe Creytens <philippe@bazookas.be>
//
// Copyright (c) 2016 Philippe Creytens
using System;

namespace Bazookas.Kinepolis.BL.Interfaces
{
	public interface IBitmapScaled
	{
		void BitmapScaledAndBlurred(object Bitmap);
	}
}

