﻿// //
// //Constants.cs$
// //
// // Author:
// //       Bruneel Robin <robin@bazookas.be>
// //
// // Copyright (c) 2015 Robin Bruneel
using System;

namespace Bazookas
{
	public static class Constants
	{
		public static int SCREEN_WIDTH 						= 0;
		public static int SCREEN_HEIGHT 					= 0;
	}
}

