﻿//
// AppController.cs
//
// Author:
//       Philippe Creytens <philippe@bazookas.be>
//
// Copyright (c) 2015 Philippe Creytens
using System;
using Bazookas.BL.Controllers;
using Bazookas.Kinepolis.BL.Interfaces;
using System.Threading;
using System.Linq.Expressions;
using System.Globalization;
using Bazookas.Kinepolis.Adapters;
using System.Diagnostics;
using Bazookas.Kinepolis.Utils;
using Bazookas.Kinepolis.SL;

namespace Bazookas.Kinepolis.BL.Controllers
{
	/// <summary>
	/// App controller Class. Main class to oversee the entire app and access non page spefic items.
	/// Type is singleton.
	/// </summary>
	public sealed class AppController : BaseAppController
	{
		#region variables

		public const string FOLDER_BLUR = "Kinepolis/Images/blur/";
		public const string FOLDERNAME_BLUR = "blur";
		public const string FOLDER_GENERAL = "Kinepolis/Images/general/";

		/// <summary>
		/// Gets or sets the bitmap cache.
		/// </summary>
		/// <value>The bitmap cache.</value>
		public object BitmapCache {
			get;
			private set;
		}

		#endregion

		#region delegates
		#endregion

		#region events
		#endregion

		#region constructor

		static readonly AppController _instance = new AppController ();

		/// <summary>
		/// Initializes a new instance of the <see cref="Bazookas.Kinepolis.BL.Controllers.AppController"/> class.
		/// </summary>
		AppController ()
		{
			#if DEBUG
			BzLogging.IsDebug = true;
			BzLogging.LogEvent += Debug.WriteLine;
			#else
			BzLogging.IsDebug = false;
			#endif

			imageController = new BaseBazookasImageController (new FileHelper (), new BazookasImageService ());
		}

		/// <summary>
		/// Gets the instance of the AppController.
		/// </summary>
		/// <value>The instance.</value>
		public static AppController Instance {
			get {
				return _instance;
			}
		}

		#endregion

		#region properties

		#region implemented abstract members of BaseAppController

		public override string PhoneID {
			get {
				return "";
			}
		}

		#endregion
		#region override properties

		#endregion

		#endregion

		#region public methods
		/// <summary>
		/// Sets the bitmap cache.
		/// </summary>
		/// <param name="cache">Cache.</param>
		/// <typeparam name="T">The 1st type parameter.</typeparam>
		public void SetBitmapCache<T>(IBitmapCache<T> cache)
		{
			this.BitmapCache = cache;
		}
			


		#region override methods
		/// <summary>
		/// Initializes the app.
		/// </summary>
		public override void InitializeApp ()
		{
			UIThreadDispatcher = new DispatchAdapter();
		}
		#endregion


		#endregion

		#region private methods

		#region appsync
		#endregion

	

		#endregion
	}
}

