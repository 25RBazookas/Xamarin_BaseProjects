﻿// //
// //RecyclerViewCell_Image_Bazookas.cs$
// //
// // Author:
// //       Bruneel Robin <robin@bazookas.be>
// //
// // Copyright (c) 2015 Robin Bruneel
using System;
using Bazookas.Kinepolis.PicassoExtension;
using Square.Picasso;

namespace Bazookas.RecyclerViewCells
{
	public class RecyclerViewCell_Image_Bazookas: RecyclerViewCell_Image, IPicassoCallBackListener
	{
		public RecyclerViewCell_Image_Bazookas (Android.Content.Context context, string imageUrl) : base (context, imageUrl)
		{
		}

		virtual public void SuccesfullLoadedImage (bool loaded)
		{

		}


		public override void LoadImage ()
		{
			ViewHolder.Image.LoadImage (ImageUrl, createThumbPattern, new PicassoCallBack (this));
		}

		RequestCreator createThumbPattern (Picasso pc, Android.Net.Uri url)
		{
			float scale = Context.Resources.DisplayMetrics.Density;
			int pixels = (int)(200 * scale + 0.5f);

			return pc.Load (url)
				.Resize (Constants.SCREEN_WIDTH, pixels)
				.OnlyScaleDown ()
				.CenterCrop ();
		}
	}
}