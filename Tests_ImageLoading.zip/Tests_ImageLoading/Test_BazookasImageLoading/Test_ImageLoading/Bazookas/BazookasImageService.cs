﻿//
// BazookasImageService.cs
//
// Author: Philippe Creytens <philippe@bazookas.be>
//
// Creation Date: 13/5/2014
//
// Copyright (c) 2014 Philippe Creytens - Bazookas
using System;
using System.IO;
using System.Threading.Tasks;
using System.Net;
using Bazookas.Utils;
using Bazookas.BL.Interfaces;
using Bazookas.BL.VO;
using Bazookas.Kinepolis.Utils;


#if __IOS__
using Foundation; 
#endif

namespace Bazookas.Kinepolis.SL
{
	#if __ANDROID__
	[Android.Runtime.Preserve(AllMembers=true)]
	#endif
	public class BazookasImageService : IBazookasImageLoader
	{
		#region variables
		static ICustomFileHelper _fileHandler = new FileHelper();
		#endregion

		public BazookasImageService ()
		{}

		/// <Summary>
		/// Downloads and saves the image in a folder async.
		/// </Summary>
		/// <returns>The image async.</returns>
		/// <param name="pictureInfo">Picture info.</param>
		/// <param name="progessReporter">Progess reporter.</param>
		/// <param name="disableIcloudBackup">If set to <c>true</c> disable icloud backup.</param>
		public async Task<ImageQueueObject> DownloadImageAsync(ImageQueueObject pictureInfo, IProgress<Bazookas.Utils.DownloadBytesProgress> progessReporter = null, bool disableIcloudBackup = true)
		{
			string urlToDownload = "";
			urlToDownload = pictureInfo.originalPicture;
			WebClient client = new WebClient();
			// https necessary
			ServicePointManager.ServerCertificateValidationCallback += (o, certificate, chain, errors) => true;

			try {
				var url = new Uri (urlToDownload);
				byte[] bytes = null;
				
				if (progessReporter != null) {
					client.DownloadProgressChanged += (sender, e) => {
						DownloadBytesProgress args = new DownloadBytesProgress (pictureInfo, urlToDownload, (int)e.BytesReceived, (int)e.TotalBytesToReceive);
						progessReporter.Report (args);
					};
				}
				
				try {
					bytes = await client.DownloadDataTaskAsync (url).WithTimeout (200000);
				} catch (OperationCanceledException) {
					return pictureInfo;
				} catch (Exception ex) {
					client.CancelAsync ();
					if(ex.InnerException != null){
						BzLogging.Log (ex.InnerException);
						BzLogging.Log (urlToDownload);
					}
					return pictureInfo;
				}

				// save image
				await _fileHandler.SaveAsync (bytes, pictureInfo.localPicture);
				#if __IOS__
				// set icloud backup
				NSFileManager.SetSkipBackupAttribute (pictureInfo.localPicture, disableIcloudBackup);
				#endif
				
				client.Dispose ();
				return pictureInfo;
			} catch (Exception ex) {
				BzLogging.SendException (ex, "ERROR LOADING IMAGE");
				return pictureInfo;
			}
		}
	}
}