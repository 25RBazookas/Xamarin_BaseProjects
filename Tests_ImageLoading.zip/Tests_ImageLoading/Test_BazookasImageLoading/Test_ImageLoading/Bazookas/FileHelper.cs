//
// FileHandler.cs
//
// Author:
//       Philippe Creytens <philippe@bazookas.be>
//
// Copyright (c) 2015 Philippe Creytens
//
using System;
using Bazookas.BL.Interfaces;
using Bazookas.Utils;
using System.IO;
using System.Threading.Tasks;

namespace Bazookas.Kinepolis.Utils
{
	public class FileHelper : ICustomFileHelper
	{
		string baseFolder = "";

		public FileHelper ()
		{
		}

		public bool Exists (string url)
		{
			return File.Exists (url);
		}

		public void Delete (string url)
		{
			File.Delete (url);
		}

		public string CombinePaths (params string[] locations)
		{
			return Path.Combine (locations);
		}

		public int FileLength (string url)
		{
			return (int)new FileInfo (url).Length;
		}

		public void Copy (string originalLocation, string toLocation)
		{
			File.Copy (originalLocation, toLocation);
		}

		public void Copy (string originalLocation, string toLocation, string baseFolder)
		{
			#if __ANDROID__
			var s = Android.App.Application.Context.Assets.Open (originalLocation);
			FileStream writeStream = new FileStream (toLocation, FileMode.OpenOrCreate, FileAccess.Write);
			ReadWriteStream (s, writeStream);
			writeStream.Close ();
			#elif __IOS__
			string libraryPath;
			var documents = iOsDeviceHardware.DocumentsPath;
			if (iOsDeviceHardware.MainSystemVersion >= 8) {
				var lib = Path.Combine (documents, "..", "Library");
				libraryPath = Path.Combine (lib, baseFolder);
			} else {
				libraryPath = Path.Combine (documents, "../Library/" + baseFolder);
			}
			if (!Directory.Exists (libraryPath)) {
				Directory.CreateDirectory (libraryPath);
			}
			var location = Path.Combine (baseFolder, originalLocation);
			Copy (location, toLocation);
			#endif
		}

		public void Copy (string originalLocation, string toLocation, params string[] optionalFolders)
		{
			Copy (originalLocation, toLocation, baseFolder, optionalFolders);
		}

		public void Copy (string originalLocation, string toLocation, string folder, params string[] optionalFolders)
		{
			#if __ANDROID__
			var s = Android.App.Application.Context.Assets.Open (originalLocation);
			FileStream writeStream = new FileStream (toLocation, FileMode.OpenOrCreate, FileAccess.Write);
			ReadWriteStream (s, writeStream);
			writeStream.Close ();
			#elif __IOS__
			string libraryPath;
			string imagePath;
			var documents = iOsDeviceHardware.DocumentsPath;
			if (iOsDeviceHardware.MainSystemVersion >= 8) {
				var lib = Path.Combine (documents, "..", "Library");
				libraryPath = Path.Combine (lib, folder);
				imagePath = Path.Combine (libraryPath, "Images");
			} else {
				libraryPath = Path.Combine (documents, "../Library/" + folder);
				imagePath = Path.Combine (documents, "../Library/" + folder + "/Images");
			}
			if (!Directory.Exists (libraryPath)) {
				Directory.CreateDirectory (libraryPath);
			}
			if (!Directory.Exists (imagePath)) {
				Directory.CreateDirectory (imagePath);
			}
			var appDir = Foundation.NSBundle.MainBundle.ResourcePath;
			var location = Path.Combine (appDir, originalLocation);
			Copy (location, toLocation);
			#endif
		}

		public string ConstructPath (string fileName, string folder)
		{
			#if __IOS__
			string libraryPath;
			var documentsPath = iOsDeviceHardware.DocumentsPath;
			libraryPath = Path.Combine (documentsPath, "..", "Library/" + folder); // Library folder
			if(!Directory.Exists(libraryPath)){
				Directory.CreateDirectory (libraryPath);
			}
			return Path.Combine (libraryPath, fileName);
			#elif __ANDROID__
			string documentsPath = Environment.GetFolderPath (Environment.SpecialFolder.Personal); // Documents folder
			return Path.Combine(documentsPath, fileName);
			#else
			// WinPhone
			return "";
			//var path = Path.Combine(Windows.Storage.ApplicationData.Current.LocalFolder.Path, sqliteFilename);;
			#endif
		}

		public string MakeDirectory (string folderName)
		{
			string fullPath = ConstructPath (folderName);

			if (!Directory.Exists (fullPath)) {
				Directory.CreateDirectory (fullPath);
			}

			return fullPath;
		}

		public bool DirectoryExists (string foldername)
		{
			string fullpath = ConstructPath (foldername);
			return Directory.Exists (fullpath);
		}

		public string ConstructPath (string fileName)
		{
			return ConstructPath (fileName, baseFolder);
		}
			 
		public void Save (byte[] bytes, string saveLocation)
		{
			FileStream fs = new FileStream (saveLocation, FileMode.OpenOrCreate);
			fs.Write (bytes, 0, bytes.Length);
			fs.Close ();
		}
		
		public async Task SaveAsync (byte[] bytes, string saveLocation)
		{
			FileStream fs = new FileStream (saveLocation, FileMode.OpenOrCreate);
			await fs.WriteAsync (bytes, 0, bytes.Length);
			fs.Close ();
			return;
		}

		public string PersonalFilePath {
			get {
				return Environment.GetFolderPath (Environment.SpecialFolder.Personal);
			}
		}

		public DateTime IsLastEditedOn (string localpath)
		{
			try {
				return File.GetLastWriteTime (localpath);
			} catch (Exception ex) {
				BzLogging.SendException (ex);
			}
			return DateTime.Now;
		}

		public string RootImagesFilePath {
			get {
				return ConstructPath ("Kinepolis/Images");
			}
		}

		public string CheckLocalElseCopyTo(string localPath)
		{
			string[] splitter = localPath.Split ('/');
			string fileName = ConstructPath (splitter[splitter.Length-1], RootImagesFilePath);
			if (!Exists (fileName)) {
				Copy (localPath, fileName);
			}
			return fileName;
		}

		public void DeleteFile(string folderName, string fileName)
		{

		}

		public void DeleteFolderContent(string folderName)
		{
			string fullPath = ConstructPath (folderName);

			if (Directory.Exists (fullPath)) {
				DirectoryInfo di = new DirectoryInfo (ConstructPath (fullPath));
				foreach (FileInfo file in di.GetFiles()) {
					file.Delete (); 
				}
				foreach (DirectoryInfo dir in di.GetDirectories()) {
					dir.Delete (true); 
				}
			}
		}

		#region private methods
		static void ReadWriteStream(Stream readStream, Stream writeStream)
		{
			const int Length = 256;
			Byte[] buffer = new Byte[Length];
			int bytesRead = readStream.Read(buffer, 0, Length);
			// write the required bytes
			while (bytesRead > 0)
			{
				writeStream.Write(buffer, 0, bytesRead);
				bytesRead = readStream.Read(buffer, 0, Length);
			}
			readStream.Close();
			writeStream.Close();
		}
		#endregion
	}
}
