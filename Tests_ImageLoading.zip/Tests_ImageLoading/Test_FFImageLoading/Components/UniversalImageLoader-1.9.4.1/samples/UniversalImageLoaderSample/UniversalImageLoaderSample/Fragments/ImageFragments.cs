﻿namespace UniversalImageLoaderSample.Fragments
{
    public enum ImageFragments
    {
        Gallery,
        Grid,
        List,
        Pager
    }
}
