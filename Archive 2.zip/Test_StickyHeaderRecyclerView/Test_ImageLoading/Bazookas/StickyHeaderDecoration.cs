﻿using System;
using System.Collections.Generic;
using Android.Graphics;
using Android.Support.V4.View;
using Android.Support.V7.Widget;
using Android.Views;
using Bazookas;

namespace Test_ImageLoading
{
	public class StickyHeaderDecoration : RecyclerView.ItemDecoration
	{

		#region variables
		IDictionary<long, RecyclerView.ViewHolder> mHeaderCache;

		Adapter_Images mAdapter;

		bool mRenderInline;
		#endregion

		#region properties
		#endregion

		#region constructors
		public StickyHeaderDecoration(Adapter_Images adapter)
		{
			mAdapter = adapter;
			mHeaderCache = new Dictionary<long, RecyclerView.ViewHolder>();
			mRenderInline = false;
		}

		/**
		 * @param adapter
		 *         the sticky header adapter to use
		 */
		public StickyHeaderDecoration(Adapter_Images adapter, bool renderInline)
		{
			mAdapter = adapter;
			mHeaderCache = new Dictionary<long, RecyclerView.ViewHolder>();
			mRenderInline = renderInline;
		}
		#endregion

		#region public methods

		public void clearHeaderCache()
		{
			mHeaderCache.Clear();
		}

		public View findHeaderViewUnder(float x, float y)
		{
			foreach (RecyclerView.ViewHolder holder in mHeaderCache.Values)
			{
				View child = holder.ItemView;
				float translationX = ViewCompat.GetTranslationX(child);
				float translationY = ViewCompat.GetTranslationY(child);

				if (x >= child.Left + translationX &&
						x <= child.Right + translationX &&
						y >= child.Top + translationY &&
					y <= child.Bottom + translationY)
				{
					return child;
				}
			}

			return null;
		}
		#region overrided methods

		public override void GetItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state)
		{
			int position = parent.GetChildAdapterPosition(view);

			int headerHeight = 0;
			if (position != RecyclerView.NoPosition && hasHeader(position))
			{
				View header = getHeader(parent, position).ItemView;
				headerHeight = getHeaderHeightForLayout(header);
			}

			outRect.Set(0, headerHeight, 0, 0);
		}


		public override void OnDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state)
		{
			int count = parent.ChildCount;

			for (int layoutPos = 0; layoutPos < count; layoutPos++)
			{
				View child = parent.GetChildAt(layoutPos);

				int adapterPos = parent.GetChildAdapterPosition(child);

				if (adapterPos != RecyclerView.NoPosition && (layoutPos == 0 || hasHeader(adapterPos)))
				{
					View header = getHeader(parent, adapterPos).ItemView;
					c.Save();
					int left = child.Left;
					int top = getHeaderTop(parent, child, header, adapterPos, layoutPos);
					c.Translate(left, top);
					header.TranslationX = left;
					header.TranslationY = top;
					header.Draw(c);
					c.Restore();
				}
			}
		}

		#endregion
		#endregion

		#region private methods

		bool hasHeader(int position)
		{
			if (position == 0)
			{
				return true;
			}

			int previous = position - 1;
			return mAdapter.getHeaderId(position) != mAdapter.getHeaderId(previous);
		}

		RecyclerView.ViewHolder getHeader(RecyclerView parent, int position)
		{
			long key = mAdapter.getHeaderId(position);

			if (mHeaderCache.ContainsKey(key))
			{
				return mHeaderCache[key];
			}
			HeaderHolder holder = mAdapter.onCreateHeaderViewHolder(parent);
			View header = holder.ItemView;

			//noinspection unchecked
			mAdapter.onBindHeaderViewHolder(holder, position);

			int widthSpec = View.MeasureSpec.MakeMeasureSpec(parent.Width, MeasureSpecMode.Exactly);
			int heightSpec = View.MeasureSpec.MakeMeasureSpec(parent.Height, MeasureSpecMode.Unspecified);

			int childWidth = ViewGroup.GetChildMeasureSpec(widthSpec, parent.PaddingLeft + parent.PaddingRight, header.LayoutParameters.Width);
			int childHeight = ViewGroup.GetChildMeasureSpec(heightSpec, parent.PaddingTop + parent.PaddingBottom, header.LayoutParameters.Height);

			header.Measure(childWidth, childHeight);
			header.Layout(0, 0, header.MeasuredWidth, header.MeasuredHeight);

			mHeaderCache.Add(key, holder);

			return holder;
		}

		int getHeaderTop(RecyclerView parent, View child, View header, int adapterPos, int layoutPos)
		{
			int headerHeight = getHeaderHeightForLayout(header);
			int top = ((int)child.GetY()) - headerHeight;
			if (layoutPos == 0)
			{
				int count = parent.ChildCount;
				long currentId = mAdapter.getHeaderId(adapterPos);
				// find next view with header and compute the offscreen push if needed
				for (int i = 1; i < count; i++)
				{
					int adapterPosHere = parent.GetChildAdapterPosition(parent.GetChildAt(i));
					if (adapterPosHere != RecyclerView.NoPosition)
					{
						long nextId = mAdapter.getHeaderId(adapterPosHere);
						if (nextId != currentId)
						{
							View next = parent.GetChildAt(i);
							int offset = ((int)next.GetY()) - (headerHeight + getHeader(parent, adapterPosHere).ItemView.Height);
							if (offset < 0)
							{
								return offset;
							}
							break;
						}
					}
				}

				top = Math.Max(0, top);
			}

			return top;
		}

		int getHeaderHeightForLayout(View header)
		{
			return mRenderInline ? 0 : header.Height;
		}

		#endregion




	}
}