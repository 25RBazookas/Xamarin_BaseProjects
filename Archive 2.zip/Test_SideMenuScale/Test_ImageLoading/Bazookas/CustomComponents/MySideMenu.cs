﻿using System;
using Android.Widget;

namespace Test_ImageLoading
{
	public class MySideMenu: RelativeLayout
	{
		#region variables
		#endregion

		#region properties
		#endregion

		#region constructors
		public MySideMenu(IntPtr javaReference, Android.Runtime.JniHandleOwnership transfer) : base(javaReference, transfer)
		{
		}

		public MySideMenu(Android.Content.Context context) : base(context)
		{
		}

		public MySideMenu(Android.Content.Context context, Android.Util.IAttributeSet attrs) : base(context, attrs)
		{
		}

		public MySideMenu(Android.Content.Context context, Android.Util.IAttributeSet attrs, int defStyle) : base(context, attrs, defStyle)
		{
		}
		#endregion

		#region public methods

		public void OpenMenu() {
			this.LayoutParameters.Width = 200;
			this.RequestLayout();
		}

		public void CloseMenu()
		{
			this.LayoutParameters.Width = 30;
			this.RequestLayout();
		}

		#region overrided methods
		#region viewlifecycle
		#endregion
		#endregion
		#endregion

		#region private methods
		#endregion
	}
}

