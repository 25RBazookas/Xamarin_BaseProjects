using Android.App;
using Test_ImageLoading;
using Android.OS;
using Bazookas.Fragments;
using Android.Views;
using System.Drawing;
using Android.Content;
using Android.Runtime;
using Android.Support.V4.Widget;
using Android.Support.V4.App;
using Android.Widget;
using Java.Lang;
using Android.Views.Animations;
using System;

namespace Bazookas.Activities
{
	//[Activity (Label = "Slidingmenu",  Theme="@style/Theme.AppCompat.Dark.NoActionBar", MainLauncher = true, Icon = "@mipmap/icon")]
	public class DrawerMenuActivity : Activity_SlidingMenu
	{
		#region delegates

		#endregion

		#region variables

		public static int SCREEN_WIDTH 						= 0;
		public static int SCREEN_HEIGHT 					= 0;

		public override int LayoutResourceId
		{
			get
			{
				return Resource.Layout.Activity_Container;
			}
		}

		#endregion

		#region properties

		#endregion

		#region constructor

		#endregion

		#region public methods

		#region overided methods

		#region viewlifecycle

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			//SIZES
			IWindowManager windowManager = this.GetSystemService(Context.WindowService).JavaCast<IWindowManager>();
			Display display = windowManager.DefaultDisplay;
			Android.Graphics.Point size = new Android.Graphics.Point();
			display.GetSize(size);
			SCREEN_HEIGHT = size.Y;
			SCREEN_WIDTH = size.X;

			//Android.Support.V4.App.Fragment fragment = new Fragment_ImageLoading_Normal (SupportFragmentManager);
			//ShowFragment (Resource.Id.activity_container, fragment, "TAG");

		}
		protected override void OnResume ()
		{
			base.OnResume ();
		}

		protected override void OnPause ()
		{
			base.OnPause ();
		}


		#endregion

		#endregion

		#endregion

		#region private methods



		#endregion

	}

	public class MyActionBarDrawerToggle:ActionBarDrawerToggle
	{
		#region variables
		#endregion

		#region properties
		public View MySpacingView
		{
			get;
			set;
		}
		public DrawerLayout MyDrawerLayout
		{
			get;
			set;
		}
		public Activity MyActivity
		{
			get;
			set;
		}
		public View MyContainer
		{
			get;
			set;
		}
		#endregion

		#region constructors
		public MyActionBarDrawerToggle(System.IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
		{
		}

		public MyActionBarDrawerToggle(Activity activity, DrawerLayout drawerLayout, int drawerImageRes, int openDrawerContentDescRes, int closeDrawerContentDescRes) : base(activity, drawerLayout, drawerImageRes, openDrawerContentDescRes, closeDrawerContentDescRes)
		{
		}

		public MyActionBarDrawerToggle(Activity activity, DrawerLayout drawerLayout, bool animate, int drawerImageRes, int openDrawerContentDescRes, int closeDrawerContentDescRes) : base(activity, drawerLayout, animate, drawerImageRes, openDrawerContentDescRes, closeDrawerContentDescRes)
		{
		}
		#endregion

		#region public methods

		public void onDrawerClosed(View view)
		{
			MyActivity.InvalidateOptionsMenu();
		}

		public void onDrawerOpened(View drawerView)
		{
			MyActivity.InvalidateOptionsMenu();
		}

		#region overrided methods


		public override void OnDrawerSlide(View drawerView, float slideOffset)
		{
			int distance = (int)slideOffset * drawerView.Width;
			Console.WriteLine("Distance is " + distance);
			MarginAnimation animation = new MarginAnimation(MyContainer, distance);
			MyContainer.StartAnimation(animation);

			MyDrawerLayout.BringChildToFront(drawerView);
			MyDrawerLayout.RequestLayout();

			base.OnDrawerSlide(drawerView, slideOffset);

		}
		#region viewlifecycle
		#endregion
		#endregion
		#endregion

		#region private methods
		#endregion
	}

	public class ResizeAnimation: Animation
	{

		private View mView;
		private float mToHeight;
		private float mFromHeight;

		private float mToWidth;
		private float mFromWidth;

		public override bool WillChangeBounds()
		{
			return true;
		}

		public override void Initialize(int width, int height, int parentWidth, int parentHeight)
		{
			base.Initialize(width, height, parentWidth, parentHeight);
		}

		public ResizeAnimation(View v, float fromWidth, float fromHeight, float toWidth, float toHeight)
		{
			mToHeight = toHeight;
			mToWidth = toWidth;
			mFromHeight = fromHeight;
			mFromWidth = fromWidth;
			mView = v;
			Duration = 300;
			Interpolator = new DecelerateInterpolator();
		}

		protected override void ApplyTransformation(float interpolatedTime, Transformation t)
		{
			//base.ApplyTransformation(interpolatedTime, t);

			float height =(mToHeight - mFromHeight) * interpolatedTime + mFromHeight;
			float width = (mToWidth - mFromWidth) * interpolatedTime + mFromWidth;
			LinearLayout.LayoutParams p = (Android.Widget.LinearLayout.LayoutParams)mView.LayoutParameters;
			p.Height = (int)height;
			p.Width = (int)width;
			mView.LayoutParameters = p;
			mView.RequestLayout();
		}
	}

	public class MarginAnimation : Animation
	{
		private View mView;
		private float mToMargin;

		public override bool WillChangeBounds()
		{
			return true;
		}

		public MarginAnimation(View v, float toMargin)
		{
			mToMargin = toMargin;
			mView = v;
			Duration = 100;
			Interpolator = new DecelerateInterpolator();
		}

		protected override void ApplyTransformation(float interpolatedTime, Transformation t)
		{
			RelativeLayout.LayoutParams p = (Android.Widget.RelativeLayout.LayoutParams)mView.LayoutParameters;
			p.LeftMargin = (int)(mToMargin * interpolatedTime);
			mView.LayoutParameters = p;
			mView.RequestLayout();
		}
	}
}
