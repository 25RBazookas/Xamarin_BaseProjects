﻿using System;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.View;
using Android.Views;
using Android.Widget;
using Bazookas.Activities;
using Bazookas.Fragments;
using com.refractored;

namespace Test_ImageLoading
{
	[Activity(Label = "Slidingmenu", Theme = "@style/Theme.AppCompat.Dark.NoActionBar", MainLauncher = true, Icon = "@mipmap/icon")]
	public class Activity_MySideBar: Activity_Base
	{
		#region delegates

		#endregion

		#region variables

		ViewPager pager;
		MyFragmentPagerAdapter adapter;
		Drawable oldBackground = null;

		PagerSlidingTabStrip tabs;

		public static int SCREEN_WIDTH = 0;
		public static int SCREEN_HEIGHT = 0;

		public override int LayoutResourceId
		{
			get
			{
				return Resource.Layout.Activity_CustomSwipeBar;
			}
		}

		#endregion

		#region properties

		#endregion

		#region constructor

		#endregion

		#region public methods

		#region overided methods

		#region viewlifecycle

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			//SIZES
			IWindowManager windowManager = this.GetSystemService(Context.WindowService).JavaCast<IWindowManager>();
			Display display = windowManager.DefaultDisplay;
			Android.Graphics.Point size = new Android.Graphics.Point();
			display.GetSize(size);
			SCREEN_HEIGHT = size.Y;
			SCREEN_WIDTH = size.X;

			Android.Support.V4.App.Fragment fragment = new Fragment_ImageLoading_Normal (SupportFragmentManager);
			ShowFragment (Resource.Id.activity_container, fragment, "TAG");


			rl = this.FindViewById<RelativeLayout>(Resource.Id.drawerView);
			TextView menuCloseButton = this.FindViewById<TextView>(Resource.Id.menuCloseButton);
			menuCloseButton.Click += closeMenuClickedHandler;

			#region SideMenuPager
			pager = (Android.Support.V4.View.ViewPager)FindViewById(Resource.Id.pager);
			tabs = FindViewById<PagerSlidingTabStrip>(Resource.Id.swipebar);

			//ADAPTER
			adapter = new MyFragmentPagerAdapter(SupportFragmentManager);
			Android.Support.V4.App.Fragment frag;
			for (int i = 0; i < 4; i++)
			{
				frag = new Android.Support.V4.App.Fragment();
				adapter.MyFragments.Add(frag);
			}

			pager.Adapter = adapter;

			//TABS
			tabs.SetViewPager(pager);
			tabs.IndicatorHeight = 50;
			changeColor(Color.Transparent);
			#endregion

		}
		int counter = 0;
		RelativeLayout rl;

		void closeMenuClickedHandler(object sender, EventArgs e)
		{
			ResizeAnimation animation = null;

			if (counter%2!=0)
			{
				animation = new ResizeAnimation(rl, rl.Width, rl.Height, 500, rl.Height);
			} else
			{
				animation = new ResizeAnimation(rl, rl.Width, rl.Height, 100, rl.Height);
			}
			rl.StartAnimation(animation);
			counter++;
		}

		protected override void OnResume()
		{
			base.OnResume();
		}

		protected override void OnPause()
		{
			base.OnPause();
		}


		#endregion

		#endregion

		#endregion

		#region private methods

		void changeColor(Color newColor)
		{
			tabs.SetBackgroundColor(newColor);
		}

		#endregion
	}
}

