﻿using System;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V4.View;
using Android.Support.V4.Widget;
using Android.Views;
using Android.Widget;
using Bazookas.Activities;
using com.refractored;

namespace Test_ImageLoading
{
	public abstract class Activity_SlidingMenu: Activity_Base
	{
		#region variables
		DrawerLayout mDrawerLayout;
		MyActionBarDrawerToggle mDrawerToggle;
		ViewPager pager;
		MyFragmentPagerAdapter adapter;
		Drawable oldBackground = null;

		PagerSlidingTabStrip tabs;

		#endregion

		#region properties
		#endregion

		#region constructors
		#endregion

		#region public methods



		//public bool OnDrag(View v, DragEvent e)
		//{
		//	e.
		//	int distance = (int)slideOffset * drawerView.Width;
		//	Console.WriteLine("Distance is " + distance);
		//	MarginAnimation animation = new MarginAnimation(MyContainer, distance);
		//	MyContainer.StartAnimation(animation);

		//	MyDrawerLayout.BringChildToFront(drawerView);
		//	MyDrawerLayout.RequestLayout();
		//}

		#region overrided methods

		//public override bool OnTouchEvent(MotionEvent e)
		//{
		//	switch (e.Action)
		//	{
		//		case (MotionEventActions.Down):
		//			return true;
		//		case (MotionEventActions.Move):
		//			return true;
		//		case (MotionEventActions.Up):
		//			return true;
		//		case (MotionEventActions.Cancel):
		//			return true;
		//		case (MotionEventActions.Outside):
		//			return true;
		//		default:
		//			return base.OnTouchEvent(e);
		//	}
		//}


		#region viewlifecycle
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			#region SideMenu
			//RelativeLayout drawerView = (RelativeLayout)FindViewById(Resource.Id.drawerView);
			pager = (Android.Support.V4.View.ViewPager)FindViewById(Resource.Id.pager);
			RelativeLayout mainView = (RelativeLayout)FindViewById(Resource.Id.activity_container);
			View scalingView = (View)FindViewById(Resource.Id.myScalingView);

			mDrawerLayout = (DrawerLayout)FindViewById(Resource.Id.drawerLayout);
			mDrawerToggle = new MyActionBarDrawerToggle(this, mDrawerLayout, Resource.Drawable.notification_template_icon_bg, Resource.String.app_name, Resource.String.app_name);
			mDrawerToggle.MySpacingView = scalingView;
			mDrawerToggle.MyActivity = this;
			mDrawerToggle.MyContainer = mainView;
			mDrawerToggle.MyDrawerLayout = mDrawerLayout;
			mDrawerLayout.SetDrawerListener(mDrawerToggle);
			mDrawerLayout.SetDrawerShadow(Resource.Color.transparent, 0);
			#endregion

			#region SideMenuPager
			tabs = FindViewById<PagerSlidingTabStrip>(Resource.Id.swipebar);

			//ADAPTER
			adapter = new MyFragmentPagerAdapter(SupportFragmentManager);
			Fragment frag;
			for (int i = 0; i < 4; i++)
			{
				frag = new Fragment();
				adapter.MyFragments.Add(frag);
			}

			pager.Adapter = adapter;

			//TABS
			tabs.SetViewPager(pager);
			tabs.IndicatorHeight = 50;
			changeColor(Color.Transparent);
			#endregion

		}
		#endregion
		#endregion
		#endregion

		#region private methods

		void changeColor(Color newColor)
		{
			tabs.SetBackgroundColor(newColor);

			//// change ActionBar color just if an ActionBar is available
			//Drawable colorDrawable = new ColorDrawable(newColor);
			//Drawable bottomDrawable = new ColorDrawable(Color.Transparent);
			//LayerDrawable ld = new LayerDrawable(new Drawable[] { colorDrawable, bottomDrawable });
			//if (oldBackground == null)
			//{
			//	SupportActionBar.SetBackgroundDrawable(ld);
			//}
			//else {
			//	TransitionDrawable td = new TransitionDrawable(new Drawable[] { oldBackground, ld });
			//	SupportActionBar.SetBackgroundDrawable(td);
			//	td.StartTransition(200);
			//}

			//oldBackground = ld;
		}
		#endregion
	}
}

