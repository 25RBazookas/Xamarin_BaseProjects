﻿using System;
using System.Collections.Generic;
using Android.Support.V4.App;

namespace Test_ImageLoading
{
	public class MyFragmentPagerAdapter : FragmentPagerAdapter
	{
		#region variables
		string[] Titles = {"title1", "title2", "title3" , "title4" };

		#endregion

		#region properties
		public override int Count
		{
			get
			{
				return MyFragments.Count;
			}
		}

		public IList<Fragment> MyFragments
		{
			get;
			set;
		}
		#endregion

		#region constructors
		public MyFragmentPagerAdapter(FragmentManager fm) : base(fm)
		{
			MyFragments = new List<Fragment>();
		}

		#endregion

		#region public methods
		#region overrided methods
		public override Fragment GetItem(int position)
		{
			return MyFragments[position];
		}

		public override Java.Lang.ICharSequence GetPageTitleFormatted(int position)
		{
			return new Java.Lang.String(Titles[position]);
		}
		#endregion
		#endregion

		#region private methods
		#endregion
	}
}

